<use layout="index" />

<block name="index">
    <div class="alert alert-danger" role="alert">
        Такой страницы не существует!
      </div>
</block>