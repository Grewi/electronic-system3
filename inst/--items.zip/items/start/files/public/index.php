<?php 
require dirname(__DIR__) . '/index.php';
