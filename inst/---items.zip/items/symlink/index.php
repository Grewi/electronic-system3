<?php 
namespace system\inst\items\symlink;
use system\core\app\app;
use system\inst\classes\itemIndex;
use system\inst\classes\functions;

class index implements itemIndex
{
    public function params() : void
    {

    }

    public function files() : void
    {

    }

    public function database() :void
    {

    }

    public function finish() :void
    {

    }    
}