<use layout="admin"/>

<block name="index">

</block>