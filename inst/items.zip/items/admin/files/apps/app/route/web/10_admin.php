<?php
use {namespace}\controllers\admin\adminController;
use {namespace}\controllers\admin\usersController;

$route->namespace()->prefix('admin')->group(ADMIN, function ($route) {
    $route->get('/')->controller(adminController::class, 'index');
});

$route->namespace()->prefix('admin')->group('admin/users', function ($route) {
    $route->get('/')->controller(usersController::class, 'index');
});

$route->namespace()->prefix('admin')->group('admin/user', function ($route) {
    $route->get('/create')->controller(usersController::class, 'create');
    $route->post('/create')->controller(usersController::class, 'createAction');
    $route->get('/edit/{user_id}')->controller(usersController::class, 'update');
    $route->post('/edit/{user_id}')->controller(usersController::class, 'updateAction');
    $route->get('/delete/{user_id}')->controller(usersController::class, 'delete');
    $route->post('/delete/{user_id}')->controller(usersController::class, 'deleteAction');
});

$route->namespace()->prefix('admin')->group('admin/roles', function($route){
    $route->get('/')->controller(usersController::class, 'index');
});
