<?php
use {namespace}\controllers\admin\adminController;
use {namespace}\controllers\admin\usersController;
use {namespace}\prefix\admin;

$route->group(ADMIN, function ($route) {
    $route->get('/')->controller(adminController::class, 'index');
}, admin::class);

$route->group('admin/users', function ($route) {
    $route->get('/')->controller(usersController::class, 'index');
}, admin::class);

$route->group('admin/user', function ($route) {
    $route->get('/create')->controller(usersController::class, 'create');
    $route->post('/create')->controller(usersController::class, 'createAction');
    $route->get('/edit/{user_id}')->controller(usersController::class, 'update');
    $route->post('/edit/{user_id}')->controller(usersController::class, 'updateAction');
    $route->get('/delete/{user_id}')->controller(usersController::class, 'delete');
    $route->post('/delete/{user_id}')->controller(usersController::class, 'deleteAction');
}, admin::class);

$route->group('admin/roles', function($route){
    $route->get('/')->controller(usersController::class, 'index');
}, admin::class);
