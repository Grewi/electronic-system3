<?php 
namespace {namespace}\configs;
class sass
{
    public function set() : array
    {
        return [
            'data' => '',
        ];
    }
}