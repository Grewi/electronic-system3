<?php 

namespace {namespace}\configs;

class sass extends \system\core\config\config
{
    public function set() : array
    {
        return [
            'data' => '',
        ];
    }
}