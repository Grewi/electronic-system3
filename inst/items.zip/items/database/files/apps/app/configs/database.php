<?php 
namespace {namespace}\configs;
!INDEX ? exit('exit') : true;

class database extends \system\core\config\config
{

    public function set() : array
    {
        return [
            'type' => '{type}',
            'name' => '{name}',
            'user' => '{user}',
            'pass' => '{pass}',
            'host' => '{host}',
            'file' => '{file}',
        ];
    }
}