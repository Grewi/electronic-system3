<?php 

namespace {namespace}\configs;

class globals extends \system\core\config\config
{
    public function set() : array
    {
        return [
            'dev'   => 0,
            'lang'  => 'ru',
            'app'   => 'app',
            'title' => 'Electronic',
            'dumpline' => 0,
        ];
    }
}