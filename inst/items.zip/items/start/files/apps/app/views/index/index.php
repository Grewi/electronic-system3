<use layout="index" />

<block name="index">
    <div class="alert alert-success" role="alert">
        Поздравляем с успешной установкой системы!
    </div>
</block>