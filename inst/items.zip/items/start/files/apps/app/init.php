<?php

use system\core\history\history;
use system\core\bootstrap\bootstrap;
use system\core\app\app;

$app = app::app();
bootstrap::load();
bootstrap::session();
history::start()->save();
require_once APP . '/route/web.php';
