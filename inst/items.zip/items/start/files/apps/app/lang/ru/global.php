<?php 

return [
    'title' => 'Electronic'
];