<?php 
use {namespace}\controllers\index\indexController;

$route->namespace('');
$route->get('/')->controller(indexController::class, 'index');