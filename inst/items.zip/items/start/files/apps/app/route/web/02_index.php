<?php 
use {namespace}\controllers\index\indexController;

$route->get('/')->controller(indexController::class, 'index');
