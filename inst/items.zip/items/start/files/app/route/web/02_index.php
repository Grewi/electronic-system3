<?php 

$route->namespace('{app}/controllers/index');
$route->get('/')->controller('indexController', 'index');