<?php 
namespace {namespace}\configs;
class globals
{
    public function set() : array
    {
        return [
            'dev'   => 0,
            'lang'  => 'ru',
            'app'   => 'app',
            'title' => 'Electronic',
            'dumpline' => 0,
        ];
    }
}