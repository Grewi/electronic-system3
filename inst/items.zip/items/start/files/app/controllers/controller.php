<?php 

namespace {namespace}\controllers;

use {namespace}\models\users;
use electronic\core\config\config;
use electronic\core\collection\collection;

abstract class controller extends \electronic\core\controller\controller
{

}