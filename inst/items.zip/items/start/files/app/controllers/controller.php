<?php 

namespace {namespace}\controllers;

use {namespace}\models\users;
use system\core\config\config;
use system\core\collection\collection;

abstract class controller extends \system\core\controller\controller
{

}