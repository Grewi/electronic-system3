SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `session_key` VARCHAR(255) NOT NULL,
  `active_time` INT NOT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `ip` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `email_code` INT DEFAULT NULL,
  `email_status` TINYINT(1) NOT NULL DEFAULT 0,
  `password` VARCHAR(255) NOT NULL,
  `name` VARCHAR(255) DEFAULT NULL,
  `login` VARCHAR(50) DEFAULT NULL,
  `active` TINYINT(1) NOT NULL,
  `user_role_id` INT NOT NULL,
  `rules` varchar(8) NULL,
  `timezone` INT NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `user_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `timezones` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `region` VARCHAR(255) NOT NULL,
  `offset` TINYINT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `user_role` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `num` INT NOT NULL,
  `rules` varchar(8) DEFAULT '00000000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

INSERT INTO `users` (`id`, `email`, `email_code`, `email_status`, `password`, `name`, `login`, `active`, `user_role_id`, `rules`, `timezone`) VALUES
(1, '{admin_email}', 0000, 1, '{admin_pass}', '{admin_login}', '{admin_login}', 1, 1, NULL, 1);

INSERT INTO `timezones` (`id`, `region`, `offset`) VALUES
(1, 'UTC', '0');

INSERT INTO `user_role` (`id`, `name`, `slug`, `num`, `rules`) VALUES
(1, 'Администратор', 'admin', 0, 'ffffffff'),
(2, 'Пользователь', 'user', 0, '00000000'),
(3, 'Гость', 'goust', 0, '00000000');

INSERT INTO `user_rules` (`id`, `slug`, `name`) VALUES
(1, 'index', 'index'),
(2, 'admin', 'admin');

ALTER TABLE `users` ADD FOREIGN KEY (`user_role_id`) REFERENCES `user_role`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `users` ADD FOREIGN KEY (`timezone`) REFERENCES `timezones`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;
