<?php 
namespace db\models;
use system\core\model\model;

class user_role extends model
{
    
}