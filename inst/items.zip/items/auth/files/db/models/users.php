<?php 
namespace db\models;
use db\models\user_role;
use system\core\model\model;

class users extends model
{    
    protected function role()
    {
        return user_role::find($this->user_role_id);
    }
    
    public function getRule(string $slug): bool
    {
        $rule = (new user_rules)->where('slug', $slug)->get();
        if(!$rule){
            throw new \Exception('error rule slug');
        }
        $mask = new maskRule($this->rules);
        return $mask->getRule($rule->id);
    }

    public function setRule(string $slug, bool $value)
    {
        $rule = (new user_rules)->where('slug', $slug)->get();
        if(!$rule){
            throw new \Exception('error rule slug');
        }
        $mask = new maskRule($this->rules);
        $mask->setRule($rule->id, $value);
        $this->rules = $mask->getRules();
        $this->save();
    }    

    public function toController()
    {
        return $this->find(user_id());
    }
}
