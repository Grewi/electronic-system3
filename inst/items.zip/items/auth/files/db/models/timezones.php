<?php 
namespace db\models;
use electronic\core\model\model;

class timezones extends model
{

}
