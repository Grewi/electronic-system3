<?php 
namespace db\models;
use system\core\model\model;

class timezones extends model
{

}
