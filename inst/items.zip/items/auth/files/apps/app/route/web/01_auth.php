<?php
use {namespace}\controllers\auth\registerController;
use {namespace}\controllers\auth\authController;

$route->get('/register')->controller(registerController::class, 'index');
$route->post('/register')->controller(registerController::class, 'register');

$route->get('/auth')->controller(authController::class, 'index');
$route->post('/auth')->controller(authController::class, 'auth'); 
$route->all('/exit')->controller(authController::class, 'out'); 
