<?php
use db\models\users;
use db\models\user_role;
use db\models\user_rules;
use system\core\system\maskRule;

if (!function_exists('rule')) {
    function rule($slug){
        $user = (new users)->find(user_id());
        $rule = (new user_rules)->where('slug', $slug)->get();
        if($user){
            return $user->getRule($slug);
        }else{
            $role = (new user_role)->where('slug', 'goust')->get();
            $mask = new maskRule($role->rules);
            return $mask->getRule($rule->id);
        }
    }    
}
