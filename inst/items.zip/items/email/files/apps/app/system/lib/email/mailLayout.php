<?php 
namespace {namespace}\system\lib\email;
use system\core\view\viewStringReturn;
trait mailLayout 
{
    private $data;

    public function layout(string $view, $data = null)
    {
        $this->data = $data;
        $this->body = (new viewStringReturn($view, $data))->return(); 
        return $this;          
    }
}
