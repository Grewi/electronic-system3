<?php 
namespace db\models;
use electronic\core\model\model;

class user_role extends model
{
    
}